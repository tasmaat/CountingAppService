﻿namespace CountingAppService
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.клиентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентскиеГруппыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.валютаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.состоянияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.номиналыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipcenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кассовыеЦентрыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rabmestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.городаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользователиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пересчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.подготовкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вскрытиеСумкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пересчетToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CpsMatchingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчётыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SendToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.наличностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сумокИлиКонтейнеровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытиеСменыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.закрытиеСменыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.разрешениеРолейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ролиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.клиентыToolStripMenuItem,
            this.справочникиToolStripMenuItem,
            this.пользователиToolStripMenuItem,
            this.пересчетToolStripMenuItem,
            this.отчётыToolStripMenuItem,
            this.SendToolStripMenuItem,
            this.сменаToolStripMenuItem,
            this.adminToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.ShowItemToolTips = true;
            // 
            // клиентыToolStripMenuItem
            // 
            this.клиентыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.клиентскиеГруппыToolStripMenuItem,
            this.клиентыToolStripMenuItem1});
            this.клиентыToolStripMenuItem.Name = "клиентыToolStripMenuItem";
            resources.ApplyResources(this.клиентыToolStripMenuItem, "клиентыToolStripMenuItem");
            // 
            // клиентскиеГруппыToolStripMenuItem
            // 
            this.клиентскиеГруппыToolStripMenuItem.Name = "клиентскиеГруппыToolStripMenuItem";
            resources.ApplyResources(this.клиентскиеГруппыToolStripMenuItem, "клиентскиеГруппыToolStripMenuItem");
            this.клиентскиеГруппыToolStripMenuItem.Click += new System.EventHandler(this.ClientGroupToolStripMenuItem_Click);
            // 
            // клиентыToolStripMenuItem1
            // 
            this.клиентыToolStripMenuItem1.Name = "клиентыToolStripMenuItem1";
            resources.ApplyResources(this.клиентыToolStripMenuItem1, "клиентыToolStripMenuItem1");
            this.клиентыToolStripMenuItem1.Click += new System.EventHandler(this.ClientsToolStripMenuItem1_Click);
            // 
            // справочникиToolStripMenuItem
            // 
            this.справочникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.валютаToolStripMenuItem,
            this.состоянияToolStripMenuItem,
            this.номиналыToolStripMenuItem,
            this.tipcenToolStripMenuItem,
            this.кассовыеЦентрыToolStripMenuItem,
            this.zoneToolStripMenuItem,
            this.rabmestToolStripMenuItem,
            this.городаToolStripMenuItem,
            this.ролиToolStripMenuItem});
            this.справочникиToolStripMenuItem.Name = "справочникиToolStripMenuItem";
            resources.ApplyResources(this.справочникиToolStripMenuItem, "справочникиToolStripMenuItem");
            // 
            // валютаToolStripMenuItem
            // 
            this.валютаToolStripMenuItem.Name = "валютаToolStripMenuItem";
            resources.ApplyResources(this.валютаToolStripMenuItem, "валютаToolStripMenuItem");
            this.валютаToolStripMenuItem.Click += new System.EventHandler(this.CurrencyToolStripMenuItem_Click);
            // 
            // состоянияToolStripMenuItem
            // 
            this.состоянияToolStripMenuItem.Name = "состоянияToolStripMenuItem";
            resources.ApplyResources(this.состоянияToolStripMenuItem, "состоянияToolStripMenuItem");
            this.состоянияToolStripMenuItem.Click += new System.EventHandler(this.ConditionToolStripMenuItem_Click);
            // 
            // номиналыToolStripMenuItem
            // 
            this.номиналыToolStripMenuItem.Name = "номиналыToolStripMenuItem";
            resources.ApplyResources(this.номиналыToolStripMenuItem, "номиналыToolStripMenuItem");
            this.номиналыToolStripMenuItem.Click += new System.EventHandler(this.DenominationToolStripMenuItem_Click);
            // 
            // tipcenToolStripMenuItem
            // 
            this.tipcenToolStripMenuItem.Name = "tipcenToolStripMenuItem";
            resources.ApplyResources(this.tipcenToolStripMenuItem, "tipcenToolStripMenuItem");
            this.tipcenToolStripMenuItem.Click += new System.EventHandler(this.tipcenToolStripMenuItem_Click);
            // 
            // кассовыеЦентрыToolStripMenuItem
            // 
            this.кассовыеЦентрыToolStripMenuItem.Name = "кассовыеЦентрыToolStripMenuItem";
            resources.ApplyResources(this.кассовыеЦентрыToolStripMenuItem, "кассовыеЦентрыToolStripMenuItem");
            this.кассовыеЦентрыToolStripMenuItem.Click += new System.EventHandler(this.CashCentresToolStripMenuItem_Click);
            // 
            // zoneToolStripMenuItem
            // 
            this.zoneToolStripMenuItem.Name = "zoneToolStripMenuItem";
            resources.ApplyResources(this.zoneToolStripMenuItem, "zoneToolStripMenuItem");
            this.zoneToolStripMenuItem.Click += new System.EventHandler(this.zoneToolStripMenuItem_Click);
            // 
            // rabmestToolStripMenuItem
            // 
            this.rabmestToolStripMenuItem.Name = "rabmestToolStripMenuItem";
            resources.ApplyResources(this.rabmestToolStripMenuItem, "rabmestToolStripMenuItem");
            this.rabmestToolStripMenuItem.Click += new System.EventHandler(this.rabmestToolStripMenuItem_Click);
            // 
            // городаToolStripMenuItem
            // 
            this.городаToolStripMenuItem.Name = "городаToolStripMenuItem";
            resources.ApplyResources(this.городаToolStripMenuItem, "городаToolStripMenuItem");
            this.городаToolStripMenuItem.Click += new System.EventHandler(this.CitiesToolStripMenuItem_Click);
            // 
            // пользователиToolStripMenuItem
            // 
            this.пользователиToolStripMenuItem.Name = "пользователиToolStripMenuItem";
            resources.ApplyResources(this.пользователиToolStripMenuItem, "пользователиToolStripMenuItem");
            this.пользователиToolStripMenuItem.Click += new System.EventHandler(this.UsersFormToolStripMenuItem_Click);
            // 
            // пересчетToolStripMenuItem
            // 
            this.пересчетToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.подготовкаToolStripMenuItem,
            this.вскрытиеСумкиToolStripMenuItem,
            this.пересчетToolStripMenuItem1,
            this.CpsMatchingToolStripMenuItem});
            this.пересчетToolStripMenuItem.Name = "пересчетToolStripMenuItem";
            resources.ApplyResources(this.пересчетToolStripMenuItem, "пересчетToolStripMenuItem");
            this.пересчетToolStripMenuItem.Click += new System.EventHandler(this.ПересчетToolStripMenuItem_Click);
            // 
            // подготовкаToolStripMenuItem
            // 
            this.подготовкаToolStripMenuItem.Name = "подготовкаToolStripMenuItem";
            resources.ApplyResources(this.подготовкаToolStripMenuItem, "подготовкаToolStripMenuItem");
            this.подготовкаToolStripMenuItem.Click += new System.EventHandler(this.PrepCountingMenuItem_Click);
            // 
            // вскрытиеСумкиToolStripMenuItem
            // 
            this.вскрытиеСумкиToolStripMenuItem.Name = "вскрытиеСумкиToolStripMenuItem";
            resources.ApplyResources(this.вскрытиеСумкиToolStripMenuItem, "вскрытиеСумкиToolStripMenuItem");
            this.вскрытиеСумкиToolStripMenuItem.Click += new System.EventHandler(this.вскрытиеСумкиToolStripMenuItem_Click);
            // 
            // пересчетToolStripMenuItem1
            // 
            this.пересчетToolStripMenuItem1.Name = "пересчетToolStripMenuItem1";
            resources.ApplyResources(this.пересчетToolStripMenuItem1, "пересчетToolStripMenuItem1");
            this.пересчетToolStripMenuItem1.Click += new System.EventHandler(this.CountingMenuItem_Click);
            // 
            // CpsMatchingToolStripMenuItem
            // 
            this.CpsMatchingToolStripMenuItem.Name = "CpsMatchingToolStripMenuItem";
            resources.ApplyResources(this.CpsMatchingToolStripMenuItem, "CpsMatchingToolStripMenuItem");
            this.CpsMatchingToolStripMenuItem.Click += new System.EventHandler(this.CpsMatchingToolStripMenuItem_Click);
            // 
            // отчётыToolStripMenuItem
            // 
            this.отчётыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.очетыToolStripMenuItem});
            this.отчётыToolStripMenuItem.Name = "отчётыToolStripMenuItem";
            resources.ApplyResources(this.отчётыToolStripMenuItem, "отчётыToolStripMenuItem");
            // 
            // очетыToolStripMenuItem
            // 
            this.очетыToolStripMenuItem.Name = "очетыToolStripMenuItem";
            resources.ApplyResources(this.очетыToolStripMenuItem, "очетыToolStripMenuItem");
            this.очетыToolStripMenuItem.Click += new System.EventHandler(this.очетыToolStripMenuItem_Click);
            // 
            // SendToolStripMenuItem
            // 
            this.SendToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наличностиToolStripMenuItem,
            this.сумокИлиКонтейнеровToolStripMenuItem});
            this.SendToolStripMenuItem.Name = "SendToolStripMenuItem";
            resources.ApplyResources(this.SendToolStripMenuItem, "SendToolStripMenuItem");
            this.SendToolStripMenuItem.Click += new System.EventHandler(this.SendCashFormToolStripMenuItem_Click);
            // 
            // наличностиToolStripMenuItem
            // 
            this.наличностиToolStripMenuItem.Name = "наличностиToolStripMenuItem";
            resources.ApplyResources(this.наличностиToolStripMenuItem, "наличностиToolStripMenuItem");
            this.наличностиToolStripMenuItem.Click += new System.EventHandler(this.наличностиToolStripMenuItem_Click);
            // 
            // сумокИлиКонтейнеровToolStripMenuItem
            // 
            this.сумокИлиКонтейнеровToolStripMenuItem.Name = "сумокИлиКонтейнеровToolStripMenuItem";
            resources.ApplyResources(this.сумокИлиКонтейнеровToolStripMenuItem, "сумокИлиКонтейнеровToolStripMenuItem");
            this.сумокИлиКонтейнеровToolStripMenuItem.Click += new System.EventHandler(this.сумокИлиКонтейнеровToolStripMenuItem_Click);
            // 
            // сменаToolStripMenuItem
            // 
            this.сменаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытиеСменыToolStripMenuItem,
            this.закрытиеСменыToolStripMenuItem});
            this.сменаToolStripMenuItem.Name = "сменаToolStripMenuItem";
            resources.ApplyResources(this.сменаToolStripMenuItem, "сменаToolStripMenuItem");
            // 
            // открытиеСменыToolStripMenuItem
            // 
            this.открытиеСменыToolStripMenuItem.Name = "открытиеСменыToolStripMenuItem";
            resources.ApplyResources(this.открытиеСменыToolStripMenuItem, "открытиеСменыToolStripMenuItem");
            this.открытиеСменыToolStripMenuItem.Click += new System.EventHandler(this.открытиеСменыToolStripMenuItem_Click);
            // 
            // закрытиеСменыToolStripMenuItem
            // 
            this.закрытиеСменыToolStripMenuItem.Name = "закрытиеСменыToolStripMenuItem";
            resources.ApplyResources(this.закрытиеСменыToolStripMenuItem, "закрытиеСменыToolStripMenuItem");
            this.закрытиеСменыToolStripMenuItem.Click += new System.EventHandler(this.закрытиеСменыToolStripMenuItem_Click);
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.разрешениеРолейToolStripMenuItem});
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            resources.ApplyResources(this.adminToolStripMenuItem, "adminToolStripMenuItem");
            // 
            // разрешениеРолейToolStripMenuItem
            // 
            this.разрешениеРолейToolStripMenuItem.Name = "разрешениеРолейToolStripMenuItem";
            resources.ApplyResources(this.разрешениеРолейToolStripMenuItem, "разрешениеРолейToolStripMenuItem");
            this.разрешениеРолейToolStripMenuItem.Click += new System.EventHandler(this.разрешениеРолейToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // ролиToolStripMenuItem
            // 
            this.ролиToolStripMenuItem.Name = "ролиToolStripMenuItem";
            resources.ApplyResources(this.ролиToolStripMenuItem, "ролиToolStripMenuItem");
            this.ролиToolStripMenuItem.Click += new System.EventHandler(this.ролиToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентскиеГруппыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem городаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem валютаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem состоянияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem номиналыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пользователиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кассовыеЦентрыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пересчетToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem подготовкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пересчетToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tipcenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчётыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rabmestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SendToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem наличностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сумокИлиКонтейнеровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вскрытиеСумкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CpsMatchingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сменаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытиеСменыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem закрытиеСменыToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem разрешениеРолейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ролиToolStripMenuItem;
    }
}

